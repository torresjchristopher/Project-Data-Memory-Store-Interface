#!/usr/bin/env python3
"""
Test script for TUI archive workflow
Tests: file selection → metadata collection → upload
"""

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))

from firebase_service import FirebaseService

def test_archive_workflow():
    """Test the complete archive workflow."""
    print("\n" + "="*70)
    print("TESTING ARCHIVE WORKFLOW")
    print("="*70)
    
    fs = FirebaseService()
    
    # Step 1: Get all people (simulating member selection)
    print("\nStep 1: Fetching all family members...")
    people = fs.get_all_people()
    print(f"✓ Found {len(people)} family members")
    
    if not people:
        print("  Creating test member...")
        person_id = fs.add_person("Test Member", "1950-01-01", "Test person")
        print(f"  ✓ Created: {person_id}")
        people = fs.get_all_people()
    
    # Display members
    print("\n  Available members:")
    for i, person in enumerate(people[:5], 1):  # Show first 5
        print(f"    {i}. {person.get('name')} (ID: {person.get('id')[:8]}...)")
    
    # Step 2: Simulate artifact upload
    print("\nStep 2: Simulating artifact metadata collection...")
    
    test_artifacts = [
        {
            'fileName': 'family_photo_1.jpg',
            'description': 'Family reunion photo from 2020',
            'tags': ['family', 'reunion', '2020'],
            'fileSize': 2048576
        },
        {
            'fileName': 'vacation_memories.mp4',
            'description': 'Summer vacation video',
            'tags': ['vacation', 'video', 'summer'],
            'fileSize': 15728640
        },
        {
            'fileName': 'birthday_cake.png',
            'description': 'Birthday celebration',
            'tags': ['birthday', 'celebration'],
            'fileSize': 1024000
        }
    ]
    
    person = people[0]
    person_id = person['id']
    person_name = person.get('name', 'Unknown')
    
    print(f"\n  Uploading to: {person_name}")
    
    uploaded = []
    for artifact in test_artifacts:
        artifact_id = fs.save_artifact(person_id, artifact)
        if artifact_id:
            uploaded.append({
                'id': artifact_id,
                'name': artifact['fileName'],
                'size': artifact['fileSize']
            })
            print(f"    ✓ {artifact['fileName']} ({artifact['fileSize']/1024:.1f} KB)")
    
    print(f"\n  Total uploaded: {len(uploaded)} artifacts")
    
    # Step 3: Verify upload
    print("\nStep 3: Verifying artifacts were saved...")
    
    all_people = fs.get_all_people()
    for person in all_people:
        if person['id'] == person_id:
            print(f"✓ Found person: {person.get('name')}")
            print(f"  - Birth Date: {person.get('birthDate')}")
            print(f"  - Bio: {person.get('bio')}")
            print(f"  - Artifacts uploaded: {len(uploaded)}")
    
    # Step 4: Test member operations
    print("\nStep 4: Testing member operations...")
    
    # Update person
    updated = fs.update_person(person_id, bio="Updated bio from TUI test")
    print(f"✓ Updated person bio: {updated}")
    
    # Test delete (create test person first)
    print("\nStep 5: Testing member deletion...")
    delete_person_id = fs.add_person("Delete Test", "2000-01-01", "To be deleted")
    deleted = fs.delete_person(delete_person_id)
    print(f"✓ Deleted test person: {deleted}")
    
    print("\n" + "="*70)
    print("ALL ARCHIVE WORKFLOW TESTS PASSED! ✓")
    print("="*70)
    print("\nSummary:")
    print(f"  - Family members: {len(all_people)}")
    print(f"  - Artifacts uploaded: {len(uploaded)}")
    print(f"  - Operations tested: CRUD (Create, Read, Update, Delete)")
    print("\n")

if __name__ == "__main__":
    test_archive_workflow()

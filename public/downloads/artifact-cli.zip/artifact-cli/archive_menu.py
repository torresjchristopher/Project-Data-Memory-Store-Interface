"""
Archive Menu - File picker and batch artifact metadata collection
Arrow key navigation with real-time display
"""

import os
import msvcrt
from pathlib import Path
from typing import List, Dict, Optional, Any
from datetime import datetime

from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.progress import Progress
from rich.live import Live
from rich import box

try:
    from rich_pixels import Pixels
except ImportError:
    Pixels = None

from PIL import Image

from file_picker import FilePicker
from firebase_service import FirebaseService


class ArchiveMenu:
    def __init__(self, firebase: FirebaseService, console: Console):
        self.firebase = firebase
        self.console = console
        self.file_picker = FilePicker()
        self.selected_files: List[Path] = []
        self.selected_person: Optional[Dict] = None
        self.metadata_batch: List[Dict[str, Any]] = []
        self.menu_index = 0
    
    def _extract_name(self, person: Dict) -> str:
        """Extract person name, handling nested dict from data migration issues."""
        name = person.get('name', 'Unknown')
        if isinstance(name, dict):
            name = name.get('name', 'Unknown')
        return str(name)
    
    def show(self):
        """Main archive menu flow with arrow key navigation."""
        menu_options = [
            "Select Files",
            "Upload Batch",
            "Back",
        ]
        menu_descriptions = [
            "Pick artifacts to add",
            "Process selected files",
            "Return to main menu",
        ]
        
        self.menu_index = 0
        
        with Live(refresh_per_second=10, screen=True) as live:
            while True:
                # Draw menu
                table = Table(box=box.ROUNDED, show_header=False, expand=True, border_style="cyan")
                
                for i, (option, desc) in enumerate(zip(menu_options, menu_descriptions)):
                    style = "bold white on cyan" if i == self.menu_index else "white"
                    prefix = "→ " if i == self.menu_index else "  "
                    table.add_row(
                        Text(f"{prefix}{option}", style=style),
                        Text(desc, style="dim")
                    )
                
                subtitle = "[dim]Arrow Keys: Navigate | Enter: Select | Q: Back[/dim]"
                if self.selected_files:
                    subtitle = f"[dim]{len(self.selected_files)} file(s) selected | {self._extract_name(self.selected_person)} | Arrow Keys: Navigate | Enter: Select | Q: Back[/dim]"
                
                panel = Panel(
                    table,
                    title="[bold]ARCHIVE[/bold]",
                    subtitle=subtitle,
                    border_style="cyan"
                )
                
                live.update(panel)
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    if key == 224:  # Arrow keys
                        direction = ord(msvcrt.getch())
                        if direction == 72:  # Up
                            self.menu_index = (self.menu_index - 1) % len(menu_options)
                        elif direction == 80:  # Down
                            self.menu_index = (self.menu_index + 1) % len(menu_options)
                    
                    elif key == 13:  # Enter
                        choice = menu_options[self.menu_index]
                        
                        if choice == "Select Files":
                            live.stop()
                            # First, select person if not already selected
                            if not self.selected_person:
                                if not self.select_person():
                                    live.start()
                                    continue
                            # Then select files
                            self.select_files()
                            live.start()
                        elif choice == "Upload Batch":
                            if self.selected_files:
                                live.stop()
                                self.process_batch()
                                live.start()
                            else:
                                live.stop()
                                self.console.print("[dim]No files selected. Please select files first.[/dim]")
                                Prompt.ask("Press Enter to continue")
                                live.start()
                        elif choice == "Back":
                            return
                    
                    elif key == ord('q'):  # Quit to main menu
                        return
    
    def select_person(self) -> bool:
        """Select which person/family to archive artifacts for."""
        people = self.firebase.get_all_people()
        
        # Add Murray Family as first option
        options = [
            {'name': 'Murray Family', 'id': 'FAMILY_ROOT', 'isFamilyRoot': True}
        ]
        options.extend(people)
        
        self.console.clear()
        self.console.print("[bold]Select person to archive for[/bold]\n")
        
        selected_idx = self._select_person_interactive(options)
        if selected_idx is not None:
            self.selected_person = options[selected_idx]
            return True
        return False
    
    def _select_person_interactive(self, people: List[Dict]) -> Optional[int]:
        """Select person using arrow keys."""
        selected = 0
        
        with Live(refresh_per_second=10, screen=True) as live:
            while True:
                table = Table(box=box.ROUNDED, show_header=False, expand=True, border_style="cyan")
                
                for idx, person in enumerate(people):
                    style = "bold white on cyan" if idx == selected else "white"
                    prefix = "→ " if idx == selected else "  "
                    table.add_row(Text(f"{prefix}{self._extract_name(person)}", style=style))
                
                panel = Panel(
                    table,
                    subtitle="[dim]Arrow Keys: Navigate | Enter: Select | Q: Cancel[/dim]",
                    border_style="cyan"
                )
                live.update(panel)
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    if key == 224:  # Arrow keys
                        direction = ord(msvcrt.getch())
                        if direction == 72:  # Up
                            selected = (selected - 1) % len(people)
                        elif direction == 80:  # Down
                            selected = (selected + 1) % len(people)
                    
                    elif key == 13:  # Enter
                        return selected
                    
                    elif key == ord('q'):  # Cancel
                        return None
    
    def select_files(self):
        """Open file picker for batch selection."""
        self.console.clear()
        self.console.print("Opening file picker...")
        self.console.print("[dim]Hold Ctrl to select multiple files\n[/dim]")
        
        files = self.file_picker.pick_files()
        
        if files:
            self.selected_files = files
            self.console.print(f"\n[green]✓[/green] Selected {len(files)} file(s)")
            
            table = Table(title="Selected Files", show_header=True, box=box.ROUNDED)
            table.add_column("Name", style="cyan")
            table.add_column("Size", style="dim")
            
            for f in files:
                size_kb = f.stat().st_size / 1024
                table.add_row(f.name, f"{size_kb:.1f} KB")
            
            self.console.print(table)
        else:
            self.console.print("[dim]No files selected.[/dim]")
        
        Prompt.ask("\nPress Enter to continue")
    
    def process_batch(self):
        """Process selected files with metadata collection."""
        self.metadata_batch = []
        total = len(self.selected_files)
        
        for idx, file_path in enumerate(self.selected_files, 1):
            self.console.clear()
            self.console.print(f"[dim]Artifact {idx} of {total} → {self.selected_person.get('name', 'Unknown')}[/dim]\n")
            
            # Show preview
            self.show_preview(file_path)
            
            # Collect metadata (no person selection - already chose person upfront)
            metadata = self.collect_metadata(file_path)
            if metadata:
                metadata['file_path'] = str(file_path)
                self.metadata_batch.append(metadata)
        
        # Summary
        self.show_batch_summary()
        
        if Confirm.ask("[bold]Upload all artifacts?[/bold]"):
            self.upload_batch()
        else:
            self.console.print("[dim]Upload cancelled.[/dim]")
            Prompt.ask("Press Enter to continue")
    
    def show_preview(self, file_path: Path):
        """Show artifact preview with actual image if available."""
        suffix = file_path.suffix.lower()
        
        if suffix in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']:
            file_type = "Image"
            # Try to display actual image using rich-pixels
            if Pixels is not None:
                try:
                    img = Image.open(str(file_path))
                    # Scale image to fit terminal (max 120 chars wide, 40 lines tall)
                    max_width = 120
                    max_height = 40
                    ratio = min(max_width / img.width, max_height / img.height)
                    new_size = (int(img.width * ratio), int(img.height * ratio))
                    img_resized = img.resize(new_size, Image.Resampling.LANCZOS)
                    
                    pixels = Pixels.from_image(img_resized)
                    self.console.print(pixels)
                    return
                except Exception:
                    pass  # Fall through to text preview
        elif suffix in ['.mp4', '.mov', '.avi', '.mkv', '.webm']:
            file_type = "Video"
        elif suffix in ['.pdf', '.doc', '.docx', '.txt']:
            file_type = "Document"
        else:
            file_type = "File"
        
        # Fallback: text preview with file info
        file_size_kb = file_path.stat().st_size / 1024
        preview_text = f"[bold]{file_path.name}[/bold]\n[dim]{file_type} • {file_size_kb:.1f} KB[/dim]"
        preview_panel = Panel(preview_text, border_style="dim", padding=(1, 2))
        self.console.print(preview_panel)
    
    def collect_metadata(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Collect metadata for a single artifact (preview stays visible)."""
        # Use console.input() to preserve the panel display above
        description = self.console.input("[bold]Description[/bold] (max 5 words, Enter to skip): ")
        
        # Enforce 5-word limit
        words = description.split()
        if len(words) > 5:
            description = " ".join(words[:5])
            self.console.print(f"[dim]Note: Optimized to 5 words: '{description}'[/dim]")
        
        # Tags
        tags = self.console.input("[bold]Tags[/bold] (comma-separated, Enter to skip): ")
        
        metadata = {
            'person_id': self.selected_person['id'],
            'person_name': self.selected_person.get('name', ''),
            'description': description,
            'tags': [t.strip() for t in tags.split(',') if t.strip()],
            'uploadedAt': datetime.now().isoformat(),
            'fileName': file_path.name,
            'fileSize': file_path.stat().st_size
        }
        
        return metadata
    
    def show_batch_summary(self):
        """Show summary of metadata to be uploaded."""
        self.console.clear()
        self.console.print("[bold]Upload Summary[/bold]\n")
        
        table = Table(title=f"{len(self.metadata_batch)} artifact(s)", box=box.ROUNDED)
        table.add_column("Name", style="cyan")
        table.add_column("Description", style="dim")
        table.add_column("Tags", style="dim")
        
        for meta in self.metadata_batch:
            desc = meta.get('description', '')[:20]
            if len(meta.get('description', '')) > 20:
                desc += "…"
            tags = ", ".join(meta.get('tags', []))[:20]
            table.add_row(
                Path(meta['file_path']).name,
                desc or "[dim]—[/dim]",
                tags or "[dim]—[/dim]"
            )
        
        self.console.print(table)
    
    def upload_batch(self):
        """Upload all artifacts to Firebase."""
        self.console.clear()
        
        with Progress() as progress:
            task = progress.add_task("Uploading...", total=len(self.metadata_batch))
            
            successful = 0
            for idx, metadata in enumerate(self.metadata_batch, 1):
                try:
                    file_path = Path(metadata['file_path'])
                    
                    # 1. Upload actual file to Storage
                    destination = f"artifacts/{metadata['person_id']}/{metadata['fileName']}"
                    public_url = self.firebase.upload_file(str(file_path), destination)
                    
                    if public_url:
                        # 2. Save metadata with the public URL
                        artifact_id = self.firebase.save_artifact(
                            metadata['person_id'],
                            {
                                'fileName': metadata['fileName'],
                                'description': metadata['description'],
                                'tags': metadata['tags'],
                                'uploadedAt': metadata['uploadedAt'],
                                'fileSize': metadata['fileSize'],
                                'url': public_url
                            }
                        )
                        
                        if artifact_id:
                            successful += 1
                    
                    progress.update(task, advance=1)
                except Exception as e:
                    self.console.print(f"[dim]Error uploading {metadata['fileName']}: {e}[/dim]")
                    progress.update(task, advance=1)
        
        self.console.print(f"\n[green]✓[/green] Uploaded {successful}/{len(self.metadata_batch)} artifact(s)")
        self.selected_files = []
        self.selected_person = None
        self.metadata_batch = []
        
        Prompt.ask("Press Enter to continue")

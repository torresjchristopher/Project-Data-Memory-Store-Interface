"""
Tree Menu - Manage family members (add, edit, delete)
Arrow key navigation with real-time display
"""

import msvcrt
from typing import List, Dict, Optional, Any
from datetime import datetime

from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.live import Live
from rich import box

from firebase_service import FirebaseService


class TreeMenu:
    def __init__(self, firebase: FirebaseService, console: Console):
        self.firebase = firebase
        self.console = console
        self.menu_index = 0
    
    def _extract_name(self, person: Dict) -> str:
        """Extract person name, handling nested dict from data migration issues."""
        name = person.get('name', 'Unknown')
        if isinstance(name, dict):
            name = name.get('name', 'Unknown')
        return str(name)
    
    def show(self):
        """Main tree management menu."""
        menu_options = [
            "View Members",
            "Add Member",
            "Edit Member",
            "Delete Member",
            "Back",
        ]
        menu_descriptions = [
            "See all family members",
            "Add new person",
            "Update person info",
            "Remove person",
            "Return to main menu",
        ]
        
        self.menu_index = 0
        
        with Live(refresh_per_second=10, screen=True) as live:
            while True:
                # Draw menu
                table = Table(box=box.ROUNDED, show_header=False, expand=True, border_style="cyan")
                
                for i, (option, desc) in enumerate(zip(menu_options, menu_descriptions)):
                    style = "bold white on cyan" if i == self.menu_index else "white"
                    prefix = "→ " if i == self.menu_index else "  "
                    table.add_row(
                        Text(f"{prefix}{option}", style=style),
                        Text(desc, style="dim")
                    )
                
                panel = Panel(
                    table,
                    title="[bold]MANAGE TREE[/bold]",
                    subtitle="[dim]Arrow Keys: Navigate | Enter: Select | Q: Back[/dim]",
                    border_style="cyan"
                )
                live.update(panel)
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    if key == 224:  # Arrow keys
                        direction = ord(msvcrt.getch())
                        if direction == 72:  # Up
                            self.menu_index = (self.menu_index - 1) % len(menu_options)
                        elif direction == 80:  # Down
                            self.menu_index = (self.menu_index + 1) % len(menu_options)
                    
                    elif key == 13:  # Enter
                        choice = menu_options[self.menu_index]
                        
                        if choice == "View Members":
                            live.stop()
                            self.view_members()
                            live.start()
                        elif choice == "Add Member":
                            live.stop()
                            self.add_member()
                            live.start()
                        elif choice == "Edit Member":
                            live.stop()
                            self.edit_member()
                            live.start()
                        elif choice == "Delete Member":
                            live.stop()
                            self.delete_member()
                            live.start()
                        elif choice == "Back":
                            return
                    
                    elif key == ord('q'):  # Quit to main menu
                        return
    
    def view_members(self):
        """Display all family members."""
        self.console.clear()
        
        people = self.firebase.get_all_people()
        
        if not people:
            self.console.print("[dim]No family members found.[/dim]")
        else:
            table = Table(title=f"{len(people)} member(s)", box=box.ROUNDED)
            table.add_column("Name", style="cyan")
            table.add_column("Birth Date", style="dim")
            table.add_column("Bio", style="dim")
            
            for person in people:
                bio = person.get('bio', '')
                if len(bio) > 35:
                    bio = bio[:35] + "…"
                table.add_row(
                    self._extract_name(person),
                    person.get('birthDate', ''),
                    bio
                )
            
            self.console.print(table)
        
        Prompt.ask("\nPress Enter to continue")
    
    def add_member(self):
        """Add a new family member."""
        self.console.clear()
        self.console.print("[bold]Add Family Member[/bold]\n")
        
        name = Prompt.ask("Name")
        if not name:
            self.console.print("[dim]Cancelled.[/dim]")
            Prompt.ask("Press Enter to continue")
            return
        
        birth_date = Prompt.ask("Birth Date (YYYY-MM-DD)", default="")
        bio = Prompt.ask("Bio (or press Enter to skip)", default="")
        
        try:
            person_id = self.firebase.add_person(name, birth_date, bio)
            
            if person_id:
                self.console.print(f"\n[green]✓[/green] Added {name}")
            else:
                self.console.print("[dim]Error: Could not add member[/dim]")
            Prompt.ask("Press Enter to continue")
        except Exception as e:
            self.console.print(f"[dim]Error adding member: {e}[/dim]")
            Prompt.ask("Press Enter to continue")
    
    def edit_member(self):
        """Edit an existing family member."""
        people = self.firebase.get_all_people()
        
        if not people:
            self.console.clear()
            self.console.print("[dim]No family members to edit.[/dim]")
            Prompt.ask("Press Enter to continue")
            return
        
        # Select person to edit
        self.console.clear()
        self.console.print("[bold]Select person to edit[/bold]\n")
        selected_idx = self._select_person(people)
        
        if selected_idx is None:
            return
        
        person = people[selected_idx]
        self.console.clear()
        self.console.print(f"[bold]Editing {self._extract_name(person)}[/bold]\n")
        
        name = Prompt.ask("Name", default=self._extract_name(person))
        birth_date = Prompt.ask("Birth Date [YYYY-MM-DD]", default=person.get('birthDate', ''))
        bio = Prompt.ask("Bio", default=person.get('bio', ''))
        
        try:
            self.firebase.update_person(person['id'], name=name, birthDate=birth_date, bio=bio)
            
            self.console.print(f"\n[green]✓[/green] Updated {name}")
            Prompt.ask("Press Enter to continue")
        except Exception as e:
            self.console.print(f"[dim]Error updating member: {e}[/dim]")
            Prompt.ask("Press Enter to continue")
    
    def delete_member(self):
        """Delete a family member."""
        people = self.firebase.get_all_people()
        
        if not people:
            self.console.clear()
            self.console.print("[dim]No family members to delete.[/dim]")
            Prompt.ask("Press Enter to continue")
            return
        
        # Select person to delete
        self.console.clear()
        self.console.print("[bold]Select person to delete[/bold]\n")
        selected_idx = self._select_person(people)
        
        if selected_idx is None:
            return
        
        person = people[selected_idx]
        
        self.console.clear()
        self.console.print(f"[bold]Delete {self._extract_name(person)}?[/bold]")
        self.console.print("[dim]This action cannot be undone.[/dim]\n")
        
        if Confirm.ask("Are you sure?"):
            try:
                self.firebase.delete_person(person['id'])
                self.console.print(f"\n[green]✓[/green] Deleted {self._extract_name(person)}")
                Prompt.ask("Press Enter to continue")
            except Exception as e:
                self.console.print(f"[dim]Error deleting member: {e}[/dim]")
                Prompt.ask("Press Enter to continue")
    
    def _select_person(self, people: List[Dict]) -> Optional[int]:
        """Select person using arrow keys."""
        selected = 0
        
        with Live(refresh_per_second=10, screen=True) as live:
            while True:
                table = Table(box=box.ROUNDED, show_header=False, expand=True, border_style="cyan")
                
                for idx, person in enumerate(people):
                    style = "bold white on cyan" if idx == selected else "white"
                    prefix = "→ " if idx == selected else "  "
                    table.add_row(Text(f"{prefix}{self._extract_name(person)}", style=style))
                
                panel = Panel(
                    table,
                    subtitle="[dim]Arrow keys: navigate | Enter: select | q: cancel[/dim]",
                    border_style="cyan"
                )
                live.update(panel)
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    if key == 224:  # Arrow keys
                        direction = ord(msvcrt.getch())
                        if direction == 72:  # Up
                            selected = (selected - 1) % len(people)
                        elif direction == 80:  # Down
                            selected = (selected + 1) % len(people)
                    
                    elif key == 13:  # Enter
                        return selected
                    
                    elif key == ord('q'):  # Cancel
                        return None

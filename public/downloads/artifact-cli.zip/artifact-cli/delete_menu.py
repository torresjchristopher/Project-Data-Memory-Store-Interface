"""
Delete Menu for Schnitzel Bank TUI
Handles searching and purging artifacts from the archive
"""

import msvcrt
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.table import Table
from rich import box
from rich.prompt import Prompt, Confirm
from firebase_service import FirebaseService
from typing import List, Dict, Any


class DeleteMenu:
    def __init__(self, firebase: FirebaseService, console: Console):
        self.firebase = firebase
        self.console = console
        self.memories = []
        self.filtered = []
        self.current_index = 0
        self.search_query = ""
        self.running = True

    def refresh_data(self):
        """Reload artifacts from database."""
        with self.console.status("[bold white]Scanning vault for artifacts..."):
            self.memories = self.firebase.get_all_memories()
            self.apply_filter()

    def apply_filter(self):
        """Filter memories based on search query."""
        q = self.search_query.lower().strip()
        if not q:
            self.filtered = self.memories
        else:
            self.filtered = [
                m for m in self.memories
                if q in (m.get('name', '') or '').lower() or
                   q in (m.get('description', '') or '').lower() or
                   q in (m.get('owner_name', '') or '').lower()
            ]
        self.current_index = 0

    def draw_list(self):
        """Draw the list of artifacts with selection highlighting."""
        table = Table(box=box.SIMPLE, expand=True, show_header=True, border_style="white")
        table.add_column("ERA", style="dim", width=6)
        table.add_column("TITLE", style="bold")
        table.add_column("SUBJECT", style="cyan")
        table.add_column("ID", style="dim", width=10)

        if not self.filtered:
            table.add_row("", "[italic red]No matches found in archive[/italic red]", "", "")
        else:
            # Display up to 15 items around current index
            start = max(0, self.current_index - 7)
            end = min(len(self.filtered), start + 15)
            
            for i in range(start, end):
                m = self.filtered[i]
                style = "bold white on grey15" if i == self.current_index else "white"
                prefix = "→ " if i == self.current_index else "  "
                
                # Extract year from date string
                year = "----"
                date_str = m.get('date', '')
                if date_str:
                    try:
                        year = date_str.split('-')[0]
                    except: pass

                table.add_row(
                    Text(year, style="dim"),
                    Text(f"{prefix}{m.get('name', 'Artifact')}", style=style),
                    Text(m.get('owner_name', 'Family'), style="cyan"),
                    Text(m['id'][:8], style="dim")
                )

        return Panel(
            table,
            title=f"[bold red]DELETE INTERFACE[/bold red] [white]({len(self.filtered)} matches)[/white]",
            subtitle=f"[dim]Query: [bold yellow]{self.search_query or '*'}[/bold yellow] | Arrows: Nav | Enter: DELETE | Esc: Back[/dim]",
            border_style="red"
        )

    def show(self):
        """Main loop for delete interface."""
        self.refresh_data()
        
        with Live(refresh_per_second=10, screen=True) as live:
            while self.running:
                live.update(self.draw_list())
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    if key == 224: # Arrow Keys
                        direction = ord(msvcrt.getch())
                        if direction == 72: # Up
                            self.current_index = (self.current_index - 1) % len(self.filtered) if self.filtered else 0
                        elif direction == 80: # Down
                            self.current_index = (self.current_index + 1) % len(self.filtered) if self.filtered else 0
                    
                    elif key == 13: # Enter (Delete)
                        if self.filtered:
                            target = self.filtered[self.current_index]
                            live.stop()
                            self.confirm_and_delete(target)
                            self.refresh_data()
                            live.start()
                    
                    elif key == 8: # Backspace
                        self.search_query = self.search_query[:-1]
                        self.apply_filter()
                    
                    elif key == 27: # Esc
                        self.running = False
                    
                    elif 32 <= key <= 126: # Character input
                        self.search_query += chr(key)
                        self.apply_filter()

    def confirm_and_delete(self, artifact: Dict[str, Any]):
        """Confirm and execute deletion."""
        self.console.print(f"\n[bold red]⚠️  WARNING: PERMANENT DELETION[/bold red]")
        self.console.print(f"Target: [bold white]{artifact.get('name')}[/bold white]")
        self.console.print(f"Subject: {artifact.get('owner_name', 'Family')}")
        
        if Confirm.ask("\n[bold red]Delete this artifact from cloud and local storage?[/bold red]", default=False):
            with self.console.status("[bold red]Executing deletion protocol..."):
                # 1. Delete from Firestore
                success = self.firebase.delete_memory(
                    artifact['id'], 
                    artifact['path_type'],
                    artifact.get('owner_id')
                )
                
                # 2. Delete from Storage (if URL exists)
                url = artifact.get('photoUrl') or artifact.get('url')
                if url:
                    self.firebase.delete_storage_file(url)
                
                if success:
                    self.console.print("✅ [bold green]Artifact deleted successfully.[/bold green]")
                else:
                    self.console.print("❌ [bold red]Metadata deletion failed.[/bold red]")
            
            Prompt.ask("\nPress Enter to return")

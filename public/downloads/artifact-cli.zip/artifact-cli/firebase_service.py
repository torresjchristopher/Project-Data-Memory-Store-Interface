"""
Firebase service for Schnitzel Bank TUI
Handles authentication and database operations
"""

import firebase_admin
from firebase_admin import credentials, firestore, storage
from pathlib import Path
import json
import os
from typing import Dict, List, Optional, Any
from datetime import datetime


class FirebaseService:
    def __init__(self):
        """Initialize Firebase connection."""
        self.initialized = False
        self.db = None
        self.init_firebase()
    
    def init_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to use service account if available
            cred_path = Path.home() / ".schnitzel" / "firebase-service-account.json"
            
            if cred_path.exists():
                cred = credentials.Certificate(str(cred_path))
                try:
                    firebase_admin.get_app()
                except ValueError:
                    # Let the Admin SDK resolve the bucket automatically
                    firebase_admin.initialize_app(cred)
                
                # Use the 'schnitzelbank' database specifically
                self.db = firestore.client(database_id='schnitzelbank')
                self.initialized = True
            else:
                # For now, we'll handle anonymous auth or use web API
                # This would need proper setup with a service account
                print("⚠️  Firebase service account not found.")
                print(f"Place firebase-service-account.json in {cred_path}")
                self.initialized = False
                
        except Exception as e:
            print(f"Firebase initialization warning: {e}")
            self.initialized = False
    
    def get_all_people(self) -> List[Dict[str, Any]]:
        """Get all people from database."""
        if not self.initialized or not self.db:
            return []
        
        try:
            # Use the 'schnitzelbank' database with protocolKey collection
            docs = self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('people').stream()
            people = []
            for doc in docs:
                person = doc.to_dict()
                person['id'] = doc.id
                people.append(person)
            return people
        except Exception as e:
            print(f"Error fetching people: {e}")
            return []
    
    def add_person(self, name: str, birth_date: Optional[str] = None, bio: str = "") -> Optional[str]:
        """Add a new person to the tree."""
        if not self.initialized or not self.db:
            return None
        
        try:
            doc_ref = self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('people').document()
            doc_ref.set({
                'name': name,
                'birthDate': birth_date or '',
                'bio': bio,
                'createdAt': datetime.now(),
                'memories': {}
            })
            return doc_ref.id
        except Exception as e:
            print(f"Error adding person: {e}")
            return None
    
    def update_person(self, person_id: str, **kwargs) -> bool:
        """Update person data."""
        if not self.initialized or not self.db:
            return False
        
        try:
            self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('people').document(person_id).update(kwargs)
            return True
        except Exception as e:
            print(f"Error updating person: {e}")
            return False
    
    def delete_person(self, person_id: str) -> bool:
        """Delete a person from the tree."""
        if not self.initialized or not self.db:
            return False
        
        try:
            # Move artifacts to 'deleted-members' tag
            self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('people').document(person_id).delete()
            return True
        except Exception as e:
            print(f"Error deleting person: {e}")
            return False
    
    def upload_file(self, file_path: str, destination: str) -> Optional[str]:
        """Upload file to Firebase Storage and return public URL."""
        if not self.initialized:
            return None
        
        try:
            # Explicitly target the firebasestorage.app bucket
            bucket = storage.bucket("schnitzelbank-a.firebasestorage.app")
            blob = bucket.blob(destination)
            blob.upload_from_filename(file_path)
            blob.make_public()
            return blob.public_url
        except Exception as e:
            print(f"Error uploading file: {e}")
            return None
    
    def save_artifact(self, person_id: str, artifact_data: Dict[str, Any]) -> Optional[str]:
        """Save artifact metadata to database."""
        if not self.initialized or not self.db:
            return None
        
        try:
            if person_id == 'FAMILY_ROOT':
                # Save to global collection
                doc_ref = (self.db.collection('trees')
                          .document('MURRAY_LEGACY_2026')
                          .collection('memories')
                          .document())
            else:
                # Save to person-specific collection
                doc_ref = (self.db.collection('trees')
                          .document('MURRAY_LEGACY_2026')
                          .collection('people')
                          .document(person_id)
                          .collection('memories')
                          .document())
            doc_ref.set(artifact_data)
            return doc_ref.id
        except Exception as e:
            print(f"Error saving artifact: {e}")
            return None

    def get_all_memories(self) -> List[Dict[str, Any]]:
        """Fetch all memories from both global and person-specific collections."""
        if not self.initialized or not self.db:
            return []
        
        memories = []
        try:
            # 1. Global memories
            global_docs = self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('memories').stream()
            for doc in global_docs:
                m = doc.to_dict()
                m['id'] = doc.id
                m['path_type'] = 'global'
                memories.append(m)
            
            # 2. Person-specific memories
            people = self.get_all_people()
            
            # Explicitly add FAMILY_ROOT to the scan to catch legacy artifacts
            scan_ids = [(p['id'], p.get('name', 'Unknown')) for p in people]
            if 'FAMILY_ROOT' not in [p[0] for p in scan_ids]:
                scan_ids.append(('FAMILY_ROOT', 'Murray Archive (Legacy)'))

            for person_id, person_name in scan_ids:
                p_docs = (self.db.collection('trees')
                         .document('MURRAY_LEGACY_2026')
                         .collection('people')
                         .document(person_id)
                         .collection('memories').stream())
                for doc in p_docs:
                    m = doc.to_dict()
                    m['id'] = doc.id
                    m['path_type'] = 'person'
                    m['owner_id'] = person_id
                    m['owner_name'] = person_name
                    memories.append(m)
            
            return memories
        except Exception as e:
            print(f"Error fetching memories: {e}")
            return []

    def delete_memory(self, memory_id: str, path_type: str, owner_id: Optional[str] = None) -> bool:
        """Delete memory metadata from Firestore."""
        if not self.initialized or not self.db:
            return False
        
        try:
            if path_type == 'global':
                ref = self.db.collection('trees').document('MURRAY_LEGACY_2026').collection('memories').document(memory_id)
            else:
                if not owner_id: return False
                ref = (self.db.collection('trees')
                      .document('MURRAY_LEGACY_2026')
                      .collection('people')
                      .document(owner_id)
                      .collection('memories')
                      .document(memory_id))
            ref.delete()
            return True
        except Exception as e:
            print(f"Error deleting memory metadata: {e}")
            return False

    def delete_storage_file(self, file_url: str) -> bool:
        """Delete a file from Firebase Storage using its URL."""
        if not self.initialized:
            return False
        
        try:
            # Parse path from URL (simple version)
            # URL format: https://storage.googleapis.com/BUCKET/artifacts/ID/NAME
            bucket = storage.bucket("schnitzelbank-a.firebasestorage.app")
            
            # Extract path from firebasestorage URL if it looks like standard one
            if "artifacts/" in file_url:
                path = "artifacts/" + file_url.split("artifacts/")[1].split("?")[0]
                blob = bucket.blob(path)
                if blob.exists():
                    blob.delete()
                    return True
            return False
        except Exception as e:
            print(f"Error deleting storage file: {e}")
            return False
